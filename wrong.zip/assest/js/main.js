$(document).ready(function () {
    $("#emailsubcribebtn").click(function () {
        var base_url = $("#base_url").val();
        var email = $.trim($("#emailsubcribe").val());

        if (email == "") {
            $("#emailsubcribe").focus();
            return false;
        }
        var form_data = "email=" + email;
        jQuery.ajax({
            url: base_url + "home/emailsubcribe_add",
            type: 'POST',
            async: true,
            data: form_data,
            dataType: 'json',
            success: function (response) {
                $("#emailsubcribe").val("");
                $("#emailsubcribemsg").html("email subcribe successfully");
            }
        });
    });

});

function join_user_add() {
    var form_data = $("#join_user_add_form").serialize();
    var base_url = jQuery("#base_url").val();

    var error = false;
    $(".form-group").removeClass("error");
    $(".form-group").find("small").addClass("hidden");
    var focus = false;
    $(".required").each(function (index) {
        if ($.trim($(this).val()) == "") {
            $(this).closest(".form-group").addClass("small");
            $(this).closest(".form-group").find("small").removeClass("hidden");
            if (!focus) {
                $(this).focus();
                focus = true
            }
            error = true;
        }
    });

    if (error) {
        return false;
    }


    jQuery.ajax({
        url: base_url + "home/join_user_add",
        type: 'POST',
        async: true,
        data: form_data,
        dataType: 'json',
        success: function (response) {
            if (response.status) {
                if (confirm(response.msg)) {
                    window.location.href = base_url;
                }
            } else {
                alert(response.msg);
            }
        }
    });
}