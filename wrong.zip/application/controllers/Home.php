<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        $this->load->model('user_model');
    }

    public function index() {
        $where = "";
        $limit = " 100";
        $data['trending'] = $this->user_model->get_trending_post();
        $data['all_post'] = $this->user_model->get_all_post($where, $limit);
        $data['category'] = $this->user_model->get_all_category_withcount();

        $data1['trending'] = $this->user_model->get_trending_post();
        $data2['category'] = $data['category'];

        $this->load->view('common/header');
        $this->load->view('common/sidebar-left', $data1);
        $this->load->view('home/index', $data);
        $this->load->view('common/sidebar-right');
        $this->load->view('common/footer', $data2);
    }

    public function join() {
        $data['category'] = $this->user_model->get_all_category();
        $data1['mostpopuler'] = $this->user_model->get_trending_post();
        $data1['trending'] = $this->user_model->get_trending_post();
        $data2['category'] = $this->user_model->get_all_category_withcount();

        $this->load->view('common/header');
        $this->load->view('common/sidebar-left', $data1);
        $this->load->view('home/join', $data);
        $this->load->view('common/sidebar-right', $data2);
        $this->load->view('common/footer');
    }

    public function join_user_add() {
//        $email = trim($this->input->post("email"));
//        $name = trim($this->input->post("name"));
//        $age = trim($this->input->post("age"));
//        $from = trim($this->input->post("from"));
//        $type = trim($this->input->post("type"));
//        $looking = trim($this->input->post("looking"));
//        $phoneno = trim($this->input->post("phoneno"));
//        $fb = trim($this->input->post("fb"));
//        $message = trim($this->input->post("message"));

        $data = $this->input->post();

        $categoty = $data['category'];
        unset($data['category']);

        $data = array_map('trim', $data);
        $status = false;
        $msg = "";
        if (trim($this->input->post("name")) == "") {
            $status = false;
            $msg = "Enter a name";
        } elseif (trim($this->input->post("message")) == "") {
            $status = false;
            $msg = "Enter a message";
        } else {
            if ($this->user_model->join_user_add($data, $categoty)) {
                $status = true;
                $msg = "Add successfully";
            } else {
                $status = false;
                $msg = "Add unsuccessfully";
            }
        }
        $data_rt = array('msg' => $msg, 'status' => $status);
        echo json_encode($data_rt);
    }

    public function getsinglepost() {
        $id = $this->uri->segment(2);
        $data['details'] = $this->user_model->getgetsinglepost($id);
        $data['category'] = $this->user_model->get_all_category();

        $data1['trending'] = $this->user_model->get_trending_post();
        $data2['category'] = $this->user_model->get_all_category_withcount();

        $this->load->view('common/header');
        $this->load->view('common/sidebar-left', $data1);
        $this->load->view('home/single', $data);
        $this->load->view('common/sidebar-right', $data2);
        $this->load->view('common/footer', $data2);
    }

    public function emailsubcribe_add() {
        if (trim($this->input->post("email")) != "") {
            $this->user_model->emailsubcribe_add($this->input->post("email"));
        }
    }

}
