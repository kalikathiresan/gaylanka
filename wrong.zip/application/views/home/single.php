<!-- >>>>>>>>>>>>>>>>>>>>
         Main Posts Area
    <<<<<<<<<<<<<<<<<<<<< -->
<div class="mag-posts-content mt-30 mb-30 p-30 box-shadow">
    <!-- ##### Post Details Area Start ##### -->
    <section class="post-details-area">
        <div class="col-12">
            <div class="post-details-content bg-white mb-30 p-30 box-shadow">
                <div class="blog-thumb mb-30">
                    <img src="img/bg-img/50.jpg" alt="">
                </div>
                <div class="blog-content">
                    <div class="post-meta">
                        <?php
                        foreach ($details['cat'] as $row) {
                            echo '<a href="#">' . $row . '</a>';
                        }
                        ?>
                    </div>
                    <h4 class="post-title"><?php echo $details['title']; ?> </h4>
                    <h5 class="post-title">Name : <?php echo $details['name']; ?> </h45>
                        <!-- Post Meta -->
                        <div class="post-meta-2">
                            <a href="#"><i class="fa fa-eye" aria-hidden="true"></i> <?php echo $details['views']; ?></a>
                            <a href="#"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i> 0</a>
                            <a href="#"><i class="fa fa-comments-o" aria-hidden="true"></i> 0</a>
                        </div>

                        <p><?php echo $details['message']; ?></p>

                        <div class="row">
                            <div class="col-12 col-lg-8">
                                <ul>
                                    <li><i class="fa fa-check-circle-o" aria-hidden="true"></i> Age : <?php echo $details['age']; ?></li>
                                    <li><i class="fa fa-check-circle-o" aria-hidden="true"></i> From Address : <?php echo $details['from_address']; ?></li>
                                    <li><i class="fa fa-check-circle-o" aria-hidden="true"></i> Looking : <?php echo $details['looking']; ?></li>
                                    <li><i class="fa fa-check-circle-o" aria-hidden="true"></i> Phone No. : <?php echo $details['phoneno']; ?></li>
                                    <li><i class="fa fa-check-circle-o" aria-hidden="true"></i> Fb : <?php echo $details['fb']; ?></li>
                                    <li><i class="fa fa-check-circle-o" aria-hidden="true"></i> Created at : <?php echo $details['created_at']; ?></li>
                                   
                                </ul>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Post Details Area End ##### -->
</div>

