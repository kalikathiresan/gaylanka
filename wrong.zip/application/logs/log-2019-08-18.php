ERROR - 2019-08-18 11:10:57 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-18 11:10:57 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 11:10:57 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 11:10:57 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 11:10:57 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:19:13 --> Severity: Notice --> Undefined variable: category C:\wamp64\www\wrong\application\views\home\join.php 62
ERROR - 2019-08-18 12:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\wrong\application\views\home\join.php 62
ERROR - 2019-08-18 12:19:58 --> Severity: Notice --> Undefined variable: category C:\wamp64\www\wrong\application\views\home\join.php 62
ERROR - 2019-08-18 12:19:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\wrong\application\views\home\join.php 62
ERROR - 2019-08-18 12:20:14 --> Severity: Notice --> Undefined variable: category C:\wamp64\www\wrong\application\views\home\join.php 62
ERROR - 2019-08-18 12:20:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\wrong\application\views\home\join.php 62
ERROR - 2019-08-18 12:20:25 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:20:25 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:20:25 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-18 12:20:25 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:20:25 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:20:38 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-18 12:20:38 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:20:38 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:20:38 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:20:38 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:22:41 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:22:41 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:22:41 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-18 12:22:41 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:22:41 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:23:03 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:23:03 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:23:03 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:23:03 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-18 12:23:03 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:28:50 --> Query error: Unknown column 'category' in 'field list' - Invalid query: INSERT INTO `user` (`title`, `email`, `name`, `age`, `from_address`, `phoneno`, `fb`, `looking`, `category`, `message`) VALUES ('i need a bottom', 'sdsd', 'sdsd', 'N/A', '', 'sds', '', 'sdsd', '5', 'sdsdsdsd')
ERROR - 2019-08-18 12:28:52 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:28:52 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:28:52 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-18 12:28:52 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:28:52 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:28:55 --> Query error: Unknown column 'category' in 'field list' - Invalid query: INSERT INTO `user` (`title`, `email`, `name`, `age`, `from_address`, `phoneno`, `fb`, `looking`, `category`, `message`) VALUES ('i need a bottom', 'sdsd', 'sdsd', 'N/A', '', 'sds', '', 'sdsd', '5', 'sdsdsdsd')
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> array_keys() expects parameter 1 to be array, integer given C:\wamp64\www\wrong\system\database\DB_query_builder.php 1566
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> sort() expects parameter 1 to be array, null given C:\wamp64\www\wrong\system\database\DB_query_builder.php 1567
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> array_keys() expects parameter 1 to be array, integer given C:\wamp64\www\wrong\system\database\DB_query_builder.php 1572
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\wamp64\www\wrong\system\database\DB_query_builder.php 1572
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> array_keys() expects parameter 1 to be array, integer given C:\wamp64\www\wrong\system\database\DB_query_builder.php 1572
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\wamp64\www\wrong\system\database\DB_query_builder.php 1572
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> ksort() expects parameter 1 to be array, integer given C:\wamp64\www\wrong\system\database\DB_query_builder.php 1579
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\wrong\system\database\DB_query_builder.php 1584
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given C:\wamp64\www\wrong\system\database\DB_query_builder.php 1572
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\wamp64\www\wrong\system\database\DB_query_builder.php 1572
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given C:\wamp64\www\wrong\system\database\DB_query_builder.php 1572
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\wamp64\www\wrong\system\database\DB_query_builder.php 1572
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given C:\wamp64\www\wrong\system\database\DB_query_builder.php 1579
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\wrong\system\database\DB_query_builder.php 1584
ERROR - 2019-08-18 12:30:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\wrong\system\database\DB_query_builder.php 1595
ERROR - 2019-08-18 12:32:39 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:32:39 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:32:40 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:32:40 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-18 12:32:40 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:32:49 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\wamp64\www\wrong\application\controllers\Home.php 62
ERROR - 2019-08-18 12:33:45 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:33:45 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:33:45 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:33:45 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:33:45 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-18 12:33:58 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\wamp64\www\wrong\application\controllers\Home.php 62
ERROR - 2019-08-18 12:35:09 --> Severity: error --> Exception: Too few arguments to function User_model::join_user_add(), 1 passed in C:\wamp64\www\wrong\application\controllers\Home.php on line 76 and exactly 2 expected C:\wamp64\www\wrong\application\models\User_model.php 5
ERROR - 2019-08-18 12:35:26 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\wamp64\www\wrong\application\models\User_model.php 35
ERROR - 2019-08-18 12:35:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\wrong\application\models\User_model.php 37
ERROR - 2019-08-18 12:35:26 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2019-08-18 12:35:58 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:35:58 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:35:58 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-18 12:35:58 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:35:58 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:50:42 --> Severity: Notice --> Undefined variable: trending C:\wamp64\www\wrong\application\views\common\sidebar-left.php 17
ERROR - 2019-08-18 12:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\wrong\application\views\common\sidebar-left.php 17
ERROR - 2019-08-18 12:50:54 --> Severity: Notice --> Undefined index: views C:\wamp64\www\wrong\application\views\common\sidebar-left.php 26
ERROR - 2019-08-18 12:50:54 --> Severity: Notice --> Undefined index: views C:\wamp64\www\wrong\application\views\common\sidebar-left.php 26
ERROR - 2019-08-18 12:50:54 --> Severity: Notice --> Undefined index: views C:\wamp64\www\wrong\application\views\common\sidebar-left.php 26
ERROR - 2019-08-18 12:50:54 --> Severity: Notice --> Undefined index: views C:\wamp64\www\wrong\application\views\common\sidebar-left.php 26
ERROR - 2019-08-18 12:50:54 --> Severity: Notice --> Undefined index: views C:\wamp64\www\wrong\application\views\common\sidebar-left.php 26
ERROR - 2019-08-18 12:50:54 --> Severity: Notice --> Undefined index: views C:\wamp64\www\wrong\application\views\common\sidebar-left.php 26
ERROR - 2019-08-18 12:50:54 --> Severity: Notice --> Undefined index: views C:\wamp64\www\wrong\application\views\common\sidebar-left.php 26
ERROR - 2019-08-18 12:50:54 --> Severity: Notice --> Undefined index: views C:\wamp64\www\wrong\application\views\common\sidebar-left.php 26
ERROR - 2019-08-18 12:50:54 --> Severity: Notice --> Undefined index: views C:\wamp64\www\wrong\application\views\common\sidebar-left.php 26
ERROR - 2019-08-18 12:50:54 --> Severity: Notice --> Undefined index: views C:\wamp64\www\wrong\application\views\common\sidebar-left.php 26
ERROR - 2019-08-18 12:52:32 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:52:32 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 12:52:32 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:52:32 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 12:52:32 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-18 12:55:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY `category`
ORDER BY `name`' at line 2 - Invalid query: SELECT `name`, COUNT(user_id) as total
GROUP BY `category`
ORDER BY `name`
ERROR - 2019-08-18 12:55:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-08-18 12:55:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY `category`
ORDER BY `name`' at line 2 - Invalid query: SELECT `name`, COUNT(id) as total
GROUP BY `category`
ORDER BY `name`
ERROR - 2019-08-18 12:55:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY `category`
ORDER BY `name`' at line 2 - Invalid query: SELECT `name`, COUNT(id) as total
GROUP BY `category`
ORDER BY `name`
ERROR - 2019-08-18 12:57:39 --> Query error: Column 'id' in field list is ambiguous - Invalid query: SELECT `name`, COUNT(id) as total
FROM `category`
LEFT JOIN `category_user` ON `category_user`.`categoryid`=`category`.`id`
GROUP BY `categoryid`
ORDER BY `name`
ERROR - 2019-08-18 12:57:49 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'wrong.category.name' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `name`, COUNT(category.id) as total
FROM `category`
LEFT JOIN `category_user` ON `category_user`.`categoryid`=`category`.`id`
GROUP BY `categoryid`
ORDER BY `name`
ERROR - 2019-08-18 13:03:10 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\wamp64\www\wrong\application\views\home\index.php 374
ERROR - 2019-08-18 13:03:41 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\wamp64\www\wrong\application\views\home\index.php 374
ERROR - 2019-08-18 13:03:42 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\wamp64\www\wrong\application\views\home\index.php 374
ERROR - 2019-08-18 13:03:42 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\wamp64\www\wrong\application\views\home\index.php 374
ERROR - 2019-08-18 13:03:42 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\wamp64\www\wrong\application\views\home\index.php 374
ERROR - 2019-08-18 13:05:25 --> Severity: error --> Exception: syntax error, unexpected end of file C:\wamp64\www\wrong\application\views\common\footer.php 139
ERROR - 2019-08-18 13:07:29 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 13:07:29 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 13:07:29 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 13:07:29 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 13:07:29 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-18 13:10:02 --> 404 Page Not Found: I-need-a-bottom5/index
ERROR - 2019-08-18 13:10:04 --> 404 Page Not Found: I-need-a-bottom5/index
ERROR - 2019-08-18 13:10:21 --> 404 Page Not Found: I-need-a-bottom5/index
ERROR - 2019-08-18 13:12:37 --> 404 Page Not Found: Post/i-need-a-bottom5
ERROR - 2019-08-18 16:17:55 --> 404 Page Not Found: Post/i-need-a-bottom
ERROR - 2019-08-18 16:17:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-08-18 16:21:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-08-18 16:36:18 --> 404 Page Not Found: Post/i-need-a-bottom
ERROR - 2019-08-18 16:36:20 --> 404 Page Not Found: Post/i-need-a-bottom
ERROR - 2019-08-18 16:36:32 --> 404 Page Not Found: Post/i-need-a-bottom
ERROR - 2019-08-18 16:36:46 --> 404 Page Not Found: Post/i-need-a-bottom
ERROR - 2019-08-18 16:36:47 --> 404 Page Not Found: Post/i-need-a-bottom
ERROR - 2019-08-18 16:36:47 --> 404 Page Not Found: Post/i-need-a-bottom
ERROR - 2019-08-18 16:36:47 --> 404 Page Not Found: Post/i-need-a-bottom
ERROR - 2019-08-18 16:36:47 --> 404 Page Not Found: Post/i-need-a-bottom
ERROR - 2019-08-18 16:37:01 --> 404 Page Not Found: Post/i-need-a-bottom
ERROR - 2019-08-18 16:48:30 --> Severity: Notice --> Undefined variable: trending C:\wamp64\www\wrong\application\views\common\sidebar-left.php 17
ERROR - 2019-08-18 16:48:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\wrong\application\views\common\sidebar-left.php 17
ERROR - 2019-08-18 16:48:30 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:48:30 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:48:30 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:48:30 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:48:30 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:48:30 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:48:58 --> Severity: Notice --> Undefined variable: trending C:\wamp64\www\wrong\application\views\common\sidebar-left.php 17
ERROR - 2019-08-18 16:48:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\wrong\application\views\common\sidebar-left.php 17
ERROR - 2019-08-18 16:48:58 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:48:58 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:48:58 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:48:58 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:48:58 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:48:58 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:14 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:14 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:14 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:14 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:14 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:14 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:25 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:25 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:25 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:25 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:25 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:25 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:49 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:49 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:49 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:49 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:49 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:49:49 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:50:15 --> Severity: Notice --> Undefined variable: trending C:\wamp64\www\wrong\application\views\common\sidebar-left.php 17
ERROR - 2019-08-18 16:50:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\wrong\application\views\common\sidebar-left.php 17
ERROR - 2019-08-18 16:50:15 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:50:15 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:50:15 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:50:15 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:50:15 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:50:15 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:50:47 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:50:47 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:50:47 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:50:47 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:50:47 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:50:47 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:51:34 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:51:34 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:51:34 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:51:34 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:51:34 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:51:34 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:52:08 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:52:08 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:52:08 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:52:08 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:52:08 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:52:08 --> Severity: Notice --> Undefined index: total C:\wamp64\www\wrong\application\views\common\sidebar-right.php 32
ERROR - 2019-08-18 16:53:30 --> Query error: Unknown table 'xuser' - Invalid query: SELECT `xuser`.*, `postmeta`.`views`, `category`.`name` as `cat`
FROM `user`
LEFT JOIN `postmeta` ON `user`.`id`=`postmeta`.`post_id`
LEFT JOIN `category_user` ON `category_user`.`userid`=`user`.`id`
LEFT JOIN `category` ON `category_user`.`categoryid`=`category`.`id`
WHERE `user`.`id` = 'i-need-a-bottom5'
ERROR - 2019-08-18 16:58:35 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 16:58:35 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 16:58:35 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-18 16:58:35 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 16:58:35 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:27 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:00:49 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:19 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:20 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:20 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:20 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:20 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:20 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:20 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:20 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:01:20 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:42 --> Severity: Notice --> Undefined index: cat C:\wamp64\www\wrong\application\models\User_model.php 104
ERROR - 2019-08-18 17:02:42 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:42 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:42 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:42 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:42 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:42 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:42 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:42 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:42 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:55 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:55 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:55 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:55 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:55 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:55 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:55 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:55 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:02:55 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:09:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\wrong\application\views\home\single.php 15
ERROR - 2019-08-18 17:09:45 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:09:45 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:09:45 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:09:45 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:09:45 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:09:45 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:09:45 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:09:45 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:09:45 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:10:16 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:10:16 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:10:16 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:10:16 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:10:16 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:10:16 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:10:16 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:10:16 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:10:16 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:10:32 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 17:10:32 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-18 17:10:32 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 17:10:32 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-18 17:10:32 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-18 17:11:02 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:02 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:02 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:02 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:02 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:02 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:02 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:02 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:02 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:32 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:32 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:32 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:32 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:32 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:32 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:32 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:32 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:11:32 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:13:46 --> Severity: Notice --> Undefined index: views C:\wamp64\www\wrong\application\views\home\single.php 24
ERROR - 2019-08-18 17:13:46 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:13:46 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:13:46 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:13:46 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:13:46 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:13:46 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:13:46 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:13:46 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:13:46 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:14:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:14:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:14:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:14:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:14:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:14:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:14:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:14:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:14:17 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:15:07 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:17:00 --> 404 Page Not Found: Post/img
ERROR - 2019-08-18 17:17:11 --> 404 Page Not Found: Post/img
