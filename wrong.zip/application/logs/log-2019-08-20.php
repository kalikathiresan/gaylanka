<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-20 16:07:32 --> 404 Page Not Found: Post/img
ERROR - 2019-08-20 16:17:47 --> 404 Page Not Found: Post/img
ERROR - 2019-08-20 16:17:52 --> 404 Page Not Found: Post/img
ERROR - 2019-08-20 16:18:11 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-20 16:18:11 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-20 16:18:11 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-20 16:18:11 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-20 16:18:11 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-20 16:18:23 --> 404 Page Not Found: Post/img
ERROR - 2019-08-20 16:18:24 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-20 16:18:24 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-20 16:18:24 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-20 16:18:24 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-20 16:18:24 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-20 16:18:54 --> 404 Page Not Found: Post/img
ERROR - 2019-08-20 16:18:54 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-20 16:18:54 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-20 16:18:54 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-20 16:18:54 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-20 16:18:54 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-20 16:19:12 --> 404 Page Not Found: Post/img
ERROR - 2019-08-20 16:19:13 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-20 16:19:13 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-20 16:19:13 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-20 16:19:13 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-20 16:19:13 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-20 16:19:32 --> 404 Page Not Found: Post/img
ERROR - 2019-08-20 16:19:33 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-20 16:19:33 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-20 16:19:33 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-20 16:19:33 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-20 16:19:33 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-20 16:21:36 --> Query error: Duplicate entry 'dfdf@sdsd.sdsd' for key 'email' - Invalid query: INSERT INTO `emailsubcribe` (`email`) VALUES ('dfdf@sdsd.sdsd')
ERROR - 2019-08-20 16:22:45 --> Query error: Duplicate entry 'dfdf@sdsd.sdsd' for key 'email' - Invalid query: INSERT INTO `emailsubcribe` (`email`) VALUES ('dfdf@sdsd.sdsd')
