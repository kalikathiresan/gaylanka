<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-19 14:33:52 --> 404 Page Not Found: Post/img
ERROR - 2019-08-19 14:40:13 --> 404 Page Not Found: Post/img
ERROR - 2019-08-19 14:40:16 --> 404 Page Not Found: Post/img
ERROR - 2019-08-19 14:40:17 --> 404 Page Not Found: Post/img
