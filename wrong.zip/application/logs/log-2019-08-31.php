<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-31 12:29:47 --> Query error: Duplicate entry 'dfdf@sdsd.sdsd' for key 'email' - Invalid query: INSERT INTO `emailsubcribe` (`email`) VALUES ('dfdf@sdsd.sdsd')
ERROR - 2019-08-31 12:29:50 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-31 12:29:50 --> 404 Page Not Found: Assest/js
ERROR - 2019-08-31 12:29:50 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-31 12:29:50 --> 404 Page Not Found: Assest/css
ERROR - 2019-08-31 12:29:50 --> 404 Page Not Found: Assest/style.css.map
ERROR - 2019-08-31 12:29:53 --> Query error: Duplicate entry 'dfdf@sdsd.sdsd' for key 'email' - Invalid query: INSERT INTO `emailsubcribe` (`email`) VALUES ('dfdf@sdsd.sdsd')
